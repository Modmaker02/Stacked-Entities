package com.stackedentities;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StackedEntitiesClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("stackedentities");

	@Override
	public void onInitializeClient() {
		StackedEntitiesConfig.load();
		ClientTickEvents.END_CLIENT_TICK.register(StackedEntitiesManager::tick);

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
			dispatcher.register(ClientCommandManager.literal("stackedentities")
				.executes(ctx -> {
					StackedEntitiesConfig c = StackedEntitiesConfig.INSTANCE;
					ctx.getSource().sendFeedback(Text.literal("§6Stacked Entities§r: " + (c.enabled ? "§aON" : "§cOFF")
						+ "§r | threshold " + c.threshold + " | hidden now: " + StackedEntitiesManager.hiddenCount()));
					return 1;
				})
				.then(ClientCommandManager.literal("toggle").executes(ctx -> {
					StackedEntitiesConfig.INSTANCE.enabled = !StackedEntitiesConfig.INSTANCE.enabled;
					StackedEntitiesConfig.save();
					ctx.getSource().sendFeedback(Text.literal("Stacked Entities: "
						+ (StackedEntitiesConfig.INSTANCE.enabled ? "§aON" : "§cOFF")));
					return 1;
				}))
				.then(ClientCommandManager.literal("threshold")
					.then(ClientCommandManager.argument("amount", IntegerArgumentType.integer(2, 1000))
						.executes(ctx -> {
							StackedEntitiesConfig.INSTANCE.threshold = IntegerArgumentType.getInteger(ctx, "amount");
							StackedEntitiesConfig.save();
							ctx.getSource().sendFeedback(Text.literal("Threshold set to "
								+ StackedEntitiesConfig.INSTANCE.threshold));
							return 1;
						})))
				.then(toggleType("windcharges", () -> StackedEntitiesConfig.INSTANCE.windCharges = !StackedEntitiesConfig.INSTANCE.windCharges))
				.then(toggleType("armorstands", () -> StackedEntitiesConfig.INSTANCE.armorStands = !StackedEntitiesConfig.INSTANCE.armorStands))
				.then(toggleType("minecarts", () -> StackedEntitiesConfig.INSTANCE.minecarts = !StackedEntitiesConfig.INSTANCE.minecarts))
			));
	}

	private static com.mojang.brigadier.builder.LiteralArgumentBuilder<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource>
	toggleType(String name, java.util.function.BooleanSupplier flip) {
		return ClientCommandManager.literal(name).executes(ctx -> {
			boolean now = flip.getAsBoolean();
			StackedEntitiesConfig.save();
			ctx.getSource().sendFeedback(Text.literal("Stacking " + name + ": " + (now ? "§aON" : "§cOFF")));
			return 1;
		});
	}
}
