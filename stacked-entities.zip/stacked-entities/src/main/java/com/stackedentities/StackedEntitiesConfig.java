package com.stackedentities;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class StackedEntitiesConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("stackedentities.json");

	public static StackedEntitiesConfig INSTANCE = new StackedEntitiesConfig();

	public boolean enabled = true;
	/** How many entities of the same kind must share one block before extras are hidden. */
	public int threshold = 2;
	public boolean windCharges = true;
	public boolean armorStands = true;
	public boolean minecarts = true;

	public static void load() {
		try {
			if (Files.exists(FILE)) {
				try (Reader r = Files.newBufferedReader(FILE)) {
					StackedEntitiesConfig c = GSON.fromJson(r, StackedEntitiesConfig.class);
					if (c != null) INSTANCE = c;
				}
			}
		} catch (Exception e) {
			StackedEntitiesClient.LOGGER.warn("Could not load config", e);
		}
		save();
	}

	public static void save() {
		try (Writer w = Files.newBufferedWriter(FILE)) {
			GSON.toJson(INSTANCE, w);
		} catch (Exception e) {
			StackedEntitiesClient.LOGGER.warn("Could not save config", e);
		}
	}
}
