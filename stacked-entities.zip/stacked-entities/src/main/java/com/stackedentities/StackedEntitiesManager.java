package com.stackedentities;

import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.projectile.AbstractWindChargeEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Every client tick, groups entities by (category, block). In each group that reaches the
 * threshold, the entity with the lowest id is the one that keeps rendering; every other
 * entity in that group is added to the hidden set and skipped by the renderer.
 */
public class StackedEntitiesManager {
	private static final int CAT_WIND = 0;
	private static final int CAT_STAND = 1;
	private static final int CAT_CART = 2;

	private static volatile IntOpenHashSet hidden = new IntOpenHashSet();

	// Reused between ticks to avoid allocations.
	private static final Long2IntOpenHashMap counts = new Long2IntOpenHashMap();
	private static final Long2IntOpenHashMap leaders = new Long2IntOpenHashMap();
	private static final List<Entity> candidates = new ArrayList<>();
	private static final List<Long> keys = new ArrayList<>();

	public static boolean isHidden(Entity entity) {
		return !hidden.isEmpty() && hidden.contains(entity.getId());
	}

	public static int hiddenCount() {
		return hidden.size();
	}

	public static void tick(MinecraftClient client) {
		ClientWorld world = client.world;
		StackedEntitiesConfig cfg = StackedEntitiesConfig.INSTANCE;
		if (world == null || !cfg.enabled) {
			if (!hidden.isEmpty()) hidden = new IntOpenHashSet();
			return;
		}

		counts.clear();
		leaders.clear();
		candidates.clear();
		keys.clear();

		for (Entity e : world.getEntities()) {
			int cat = category(e, cfg);
			if (cat < 0 || e.isRemoved()) continue;

			long key = e.getBlockPos().asLong() * 4L + cat;
			counts.addTo(key, 1);

			int id = e.getId();
			if (!leaders.containsKey(key) || id < leaders.get(key)) leaders.put(key, id);

			candidates.add(e);
			keys.add(key);
		}

		IntOpenHashSet next = new IntOpenHashSet();
		int min = Math.max(2, cfg.threshold);
		for (int i = 0; i < candidates.size(); i++) {
			long key = keys.get(i);
			if (counts.get(key) >= min && candidates.get(i).getId() != leaders.get(key)) {
				next.add(candidates.get(i).getId());
			}
		}
		hidden = next;
	}

	private static int category(Entity e, StackedEntitiesConfig cfg) {
		if (cfg.windCharges && e instanceof AbstractWindChargeEntity) return CAT_WIND;
		if (cfg.armorStands && e instanceof ArmorStandEntity) return CAT_STAND;
		if (cfg.minecarts && e instanceof AbstractMinecartEntity) return CAT_CART;
		return -1;
	}
}
